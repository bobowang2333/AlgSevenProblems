//
//  main.cpp
//  CornFields
//
//  Created by bobobo on 11/14/15.
//  Copyright © 2015 bobobo. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <queue>
#include <algorithm>
#include <cstring>
using namespace std;

int n,m; //m  行 n  列
int row[12];//12行 12种状态 1000011110110101诸如此类 1可以种植 0不可以
int nState,state[1000];
int dp[14][1000];
#define MOD 100000000

void init()
{
    int k = 1 << n;
    nState = 0;
    for (int i = 0; i < k; i++) {
        if ((i&(i << 1)) == 0) {
            //相邻之间不能同时为1
            state[nState++] = i;
        }
    }
}
int main(int argc, const char * argv[]) {
    int k;
    scanf("%d %d",&m,&n);
    init();
    
    //输入每一行的草地状态
    for (int i = 0; i < m; i++) {
        row[i] = 0;
        for (int j = n - 1; j >= 0; j--) {
            scanf("%d",&k);
            row[i] += k << j;
        }
    }
    //满足第0行草地 的状态
    for (int i = 0; i < nState; i++) {
        dp[0][i] = ((row[0] & state[i]) == state[i])?1:0;
    }
    
    // 求dp[i]，如果state[j]和第i-1行的状态state[k]不冲突，则dp[i][j]=Σ(dp[i-1][k])
    for(int  i = 1;i < m;i++)
        for (int j = 0; j < nState; j++) {
            if ((row[i] & state[j]) != state[j])
                continue;
            for (int l = 0; l < nState; l++) {
                if ((dp[i - 1][l]) && ((state[l] & state[j]) == 0)) {
                    dp[i][j] = (dp[i - 1][l] + dp[i][j])%MOD;
                }
            }
        }
    
    int result = 0;
    for (int j = 0; j < nState; j++) {
        if (dp[m - 1][j]) {
            result += dp[m - 1][j];
            result = result % MOD;
        }
    }
    cout<<result;
    return 0;
}
