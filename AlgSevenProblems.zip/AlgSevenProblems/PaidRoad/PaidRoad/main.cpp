//
//  main.cpp
//  PaidPaidRoad
//
//  Created by bobobo on 11/14/15.
//  Copyright © 2015 bobobo. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int inf=(unsigned)((1 << 31) - 1);
//int map[15][15];
int vis[15];
int n,m;
int ans;
struct node
{
    int a;
    int b;
    int c;
    int p;
    int r;
}PaidRoad[15];
void dfs(int u,int v)
{
    if(v>ans)
        return;
    if(u==n)
    {
        if(v<ans)
        {
            ans=v;
            // printf("  %d\n",ans);
        }
        return;
    }
    for(int i=1;i<=m;i++)
    {
        if(PaidRoad[i].a==u&&vis[PaidRoad[i].b]<=3)
        {
            int b=PaidRoad[i].b;
            vis[b]++;
            if(vis[PaidRoad[i].c])
            {
                dfs(b,v+PaidRoad[i].p);
            }
            else
            {
                dfs(b,v+PaidRoad[i].r);
            }
            vis[b]--;
        }
    }
    return;
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        memset(vis,0,sizeof(vis));
        ans=inf;
        for(int i=1;i<=m;i++)
        {
            scanf("%d%d%d%d%d",&PaidRoad[i].a,&PaidRoad[i].b,&PaidRoad[i].c,&PaidRoad[i].p,&PaidRoad[i].r);
        }
        vis[1]=1;
        dfs(1,0);
        if(ans==inf)
            printf("impossible\n");
        else
            printf("%d\n",ans);
    }
    return 0;
}