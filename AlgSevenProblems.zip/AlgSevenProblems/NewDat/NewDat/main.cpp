//
//  main.cpp
//  NewDat
//
//  Created by bobobo on 11/9/15.
//  Copyright © 2015 bobobo. All rights reserved.
//

#include <stdio.h>
#include <iostream>
#include <time.h>
#include <fstream>
using namespace std;
const int mxsz = 100000 + 10; //最大点数const double oo = 1e20;       无穷大距离

struct Point
{
    int x, y;
    Point(int  a = 0, int b = 0) : x(a), y(b) {}
} v[mxsz], tem[mxsz];     //点集, 中间点集

#define MAX 10

#define MaxVertice 100   //避免产生的数组会越界
#define MaxEdge 50
#define oo 65535   //表示两点间距离为无穷大

typedef int PointPath [MaxVertice][MaxVertice];
typedef int ShortPathTable [MaxVertice][MaxVertice];

typedef struct
{
    int vertice[MaxVertice];
    int IngTable[MaxVertice][MaxVertice];
    int numVertice,numEdge;
} MatrixGraph;

/* 最近点对产生测试文件.dat
int main(int argc, char* argv[])
{
    srand( (unsigned)time( NULL ) );//srand()函数产生一个以当前时间开始的随机种子.应该放在for等循环语句前面 不然要很长时间等待
    //for (int i=0;i<10;i++)
        //cout<<rand()%MAX<<endl;//MAX为最大值，其随机域为0~MAX-1
    int n = 100;
    int arr[100];
    //fstream outFile;
    
    //ofstream outFile("in.dat");
    fstream outFile("in.dat",ios::out|ios::binary);
    //ofstream outFile("in.dat",ios::binary);
    outFile.write((char *)&n,sizeof(n));
    for(int q = 0;q < 100;q++)
    {
        int j = rand()%MAX;
        arr[q] = j;
        outFile.write((char *)&(arr[q]),sizeof(arr[q]));
        for(int k = 0;k < j;k++)
        {
            v[q+k].x = rand()%MAX;
            v[q+k].y = rand()%MAX;
            outFile.write((char *)&v[q+k],sizeof(v[q+k]));
        }
    }
    outFile.close();
    return 0;
}*/


/*  最近点对对输出的文件out.dat进行检测
int main(int argc,char* argv[])
{
    ifstream infile("/users/bobobo/Documents/AlgTestFile/out.dat",ios::binary);
    if(!infile)
    {
        cerr<<"open error!"<<endl;
        abort();
    }
    int i = 0;
    while (infile) {
        infile.read((char *)&v[i++] ,sizeof(v[i++]));
        cout<<"The x is:"<<v[i - 1].x<<endl;
        cout<<"The y is:"<<v[i - 1].y<<endl;
    }
    infile.close();
    return 0;
}*/

/*最近点对显示测试数据的数据
int main(int argc,char* argv[])
{
    ifstream fin("/users/bobobo/Documents/AlgSevenProblems/FileInputOutput/in.dat",ios::binary);
    if (!fin) {
        cerr<<"open error!"<<endl;
        abort();
    }
    int k,j;
    int cal = 0;
    fin.read((char *)&k, sizeof(k));
    cout<<"The Number of The Group:"<<k<<endl;
    for(int i = 0; i < k; i++)
    {
        fin.read((char *)&j, sizeof(j));
        cout<<"the Number of the datas:"<<j<<endl;
        for (int t = 0; t < j; t++) {
            fin.read((char *)&v[cal++], sizeof(v[cal++]));
            cout<<"the x:"<<v[cal - 1].x;
            cout<<"the y :"<<v[cal - 1].y<<endl;
        }
    }
}*/

/*制造flyod算法测试数据
int main(int argc , char* argv[])
{
    srand((unsigned)time(NULL));
    int n = rand()%MAX;
    MatrixGraph m[n];
    fstream fout("in.dat",ios::binary|ios::out);
    fout.write((char *)&n, sizeof(n));
    // n 组测试数据
    for (int q = 0; q < n; q++) {
        //每个测试数据组有j个点
        int j = rand()%MAX;
        m[q].numVertice = j;
        
        fout.write((char *)&j, sizeof(j));
        for (int k = 0; k < j; k++){
            for (int l = 0; l < j; l++) {
                m[q].IngTable[k][l] = rand()%MAX;
                if ((m[q].IngTable[k][l]) == 0) {
                    m[q].IngTable[k][l] = 32767;
                }
            }
            fout.write((char *)&(m[q].IngTable[k]), sizeof(m[q].IngTable[k]));
        }
    }
    fout.close();
    return 0;
}*/


/*对flyod输出的文件进行监测
int main(int argc ,char* argv[])
{
    ifstream fin("/users/bobobo/Documents/AlgSevenProblems/FlyodAlgorithm/FlyodAlgorithm/out.dat",ios::binary|ios::in);
    if (!fin) {
        cerr<<"open error!"<<endl;
        abort();
    }
    int num1,num2;
    fin.read((char *)&num1, sizeof(num1));
    MatrixGraph m[num1];
    PointPath d[num1];
    ShortPathTable p[num1];
    cout<<"the number of test group is:"<<num1<<endl;
    for (int i = 0;i < num1; i++) {
        fin.read((char *)&(num2), sizeof(num2));
        cout<<" the test group - "<<i<<"-points-"<<num2<<endl;
        //输出最短距离 n*n矩阵
        for (int j = 0; j < num2; j++){
            fin.read((char *)&(d[i][j]), sizeof(d[i][j]));
            for (int k = 0; k < num2; k++) {
                if (d[i][j][k] >= 32767) {
                    d[i][j][k] = 32767;
                }
                if (k == num2-1) {
                    cout<<d[i][j][k]<<endl;
                }else
                {
                    cout<<d[i][j][k]<<" ";
                }
            }
        }
        for (int k = 0;k < num2; k++) {
            fin.read((char *)&(p[i][k]), sizeof(p[i][k]));
        }
        // 点对从k->>>j
        for (int k = 0; k < num2; k++) {
            for (int j = 0; j < num2; j++) {
                cout<<"("<<k<<","<<j<<")"<<":";
                int tmp = p[i][k][j];
                if (((k != j)&&(tmp == j))||(d[i][k][j] == 32767)) {
                    cout<<"NULL"<<endl;
                }else{
                while (tmp != j) {
                    cout<<tmp<<" ";
                    tmp = p[i][tmp][j];
                }
                cout<<j<<endl;
              }
            }
        }

    }
    fin.close();
}*/

//显示Flyod测试的数据
int main(int argc,char* argv[])
{
    ifstream fin("/users/bobobo/Documents/AlgSevenProblems/FlyodAlgorithm/FlyodAlgorithm/in.dat",ios::binary|ios::in);
    if(!fin){
        cerr<<"open error"<<endl;
        abort();
    }
    int num1,num2;
    fin.read((char *)&num1, sizeof(num1));
    MatrixGraph m[num1];
    cout<<"the number of test group:"<<num1<<endl;
    for (int i = 0; i < num1; i++) {
        fin.read((char *)&num2, sizeof(num2));
        cout<<"the number of group-"<<i<<":has point:"<<num2<<endl;
        for (int k = 0; k < num2; k++) {
            fin.read((char *)&(m[i].IngTable[k]), sizeof(m[i].IngTable[k]));
        }
        for (int k = 0; k < num2; k++) {
            for (int y = 0 ; y < num2; y++) {
                cout<<(m[i].IngTable[k][y])<<" ";
            }
            cout<<endl;
        }
    }
    fin.close();
    return 0;
}




//输出前驱点  n*n行   每行限制n个数据以内
/*
 for (int l = 0; l < num2; l++) {
 for(int y = 0;y < num2;y++){
 cout<<"("<<l<<","<<y<<")"<<endl;
 fin.read((char *)&(vertice[l*num2+y]), sizeof(vertice[l*num2+y]));
 int cal = 0;
 while (!(vertice[l*num2+y][cal]))
 {
 cout<<vertice[l*num2+y][cal]<<" ";
 cal++;
 }
 cout<<endl;
 }
 }*/