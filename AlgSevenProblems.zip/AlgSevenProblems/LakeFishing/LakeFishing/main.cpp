//
//  main.cpp
//  LakeFishing
//
//  Created by bobobo on 11/14/15.
//  Copyright © 2015 bobobo. All rights reserved.
//

#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;
const int MAXSIZE = 50;
int n ,h;
int f[MAXSIZE],d[MAXSIZE],t[MAXSIZE];
int ResultTime[MAXSIZE];
int TestTime[MAXSIZE];
int updateFish[MAXSIZE];
int result;

void init()
{
    memset(ResultTime, 0, sizeof(ResultTime));
    memset(TestTime, 0, sizeof(TestTime));
    result = 0;
}

bool input()
{
    init();
    scanf("%d",&n);
    if (n == 0) {
        return false;
    }
    scanf("%d",&h);
    for (int i = 0; i < n; i++) {
        scanf("%d",f+i);
    }
    for (int i = 0; i < n; i++) {
        scanf("%d",d+i);
    }
    for (int i = 0; i < n - 1; i++) {
        scanf("%d",t+i);
    }
    return true;
}

void ListLakeResult(int SumTime,int LakeNum)
{
    int Tmpresult = 0;
    memset(TestTime, 0, sizeof(TestTime));
    memcpy(updateFish, f, sizeof(f));  //复制湖中鱼的初始数量给更新时的鱼量
    for (int i = 0; i < SumTime; i++) {
        int pos = 0,MaxFish = updateFish[0];
        if (LakeNum > 0) {
            for (int k = 0; k < LakeNum; k++) {
                if(updateFish[k] > MaxFish)
                {
                    MaxFish = updateFish[k];
                    pos = k;
                }
            }
        }
        TestTime[pos]  += 1; //在pos处多钓了一次5分钟的鱼
        Tmpresult += updateFish[pos];
        updateFish[pos] -= d[pos];
        if (updateFish[pos] < 0) {
            updateFish[pos] = 0;
        }
    }
    if (Tmpresult > result) {
        result = Tmpresult;
        memcpy(ResultTime, TestTime, sizeof(TestTime));
    }else if(Tmpresult == result)
    {
        int i;
        for ( i = 0; i < n; i++) {
            if (TestTime[i] != ResultTime[i])
                break;
        }
        if (TestTime[i] > ResultTime[i]) {
            memcpy(ResultTime, TestTime, sizeof(TestTime));
        }
    }
}

void print()
{
    for (int  i = 0 ; i < n - 1; i++) {
        cout<<(ResultTime[i]*5)<<" ";
    }
    cout<<(ResultTime[n - 1]*5)<<endl;
    cout<<"Number of Fish Expected:"<<result<<endl;
}

int main(int argc, const char * argv[]) {
    while (input()) {
        int FiveMinuteTime = h*12;  //h*60/5
        ListLakeResult(FiveMinuteTime, 0);
        for (int i = 0; i < n - 1; i++) {
            FiveMinuteTime -= t[i];
            ListLakeResult(FiveMinuteTime, i+1);
        }
        print();
    }
    return 0;
}
