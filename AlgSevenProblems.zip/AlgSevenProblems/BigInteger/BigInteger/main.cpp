//
//  main.cpp
//  BigInteger
//
//  Created by bobobo on 11/10/15.
//  Copyright © 2015 bobobo. All rights reserved.
//

#include <cstdlib>
#include <iostream>
#include <string>
#include <sstream>

using namespace std;
string sub(string s1,string s2);

//返回两个数相乘的字符串结果
string mutiply(string& a, string& b)
{
    int num1 = atol(a.c_str());
    int num2 = atol(b.c_str());
    
    stringstream ss;
    string s;
    ss << num1*num2;
    ss >> s;
    
    return s;
}
//返回两个数字相减的结果 判断字符串首位符号是否为负数
inline int compare(string s1 ,string s2)
{
    if(s1.size() < s2.size())
        return -1;
    else if(s1.size() > s2.size())
        return -1;
    else
        return s1.compare(s2);   //如果所比较的两个string 相等，则返回0； 操作string 大于参数string,返回
                                  //正数；操作string 小于参数string,返回负数。
}

//返回两个数相加的字符串结果
string add(string& a, string& b)
{
    if (a == "0") {
        return  b;
    }
    if (b == "0") {
        return a;
    }
    
    if (a[0] == '-') {
        if (b[0] == '-' ) {
            return "-" + add(a.erase(0,1), b.erase(0,1));
        }
        return sub(b, a.erase(0,1));
    }
    
    if (b[0] == '-') {
        return sub(a, b.erase(0,1));
    }
    int len1 = a.length(), len2 = b.length(), i, j;
    
    //a>=b
    if(len1 < len2){
        string t = a;
        a = b;
        b = t;
        int t0 = len1;
        len1 = len2;
        len2 = t0;
    }
    
    for(i = len1-1, j = len2-1;i >= 0, j >= 0; i--, j--){
        int t = a[i] - '0' + b[j] - '0' ;
        
        if(t >= 10){
            a[i] = t - 10 + '0';
            
            if(i > 0){
                a[i-1] = a[i-1] + 1;
            }else{
                a = '1' + a;
            }
            
        }else{
            a[i] = t + '0';
        }
    }
    
    if(i >= 0){
        for(j = i; j>= 0; j--){
            if(a[j] >= 58){
                a[j] = a[j] - 10;
                
                if(j > 0){
                    a[j-1] = a[j-1] + 1;
                }else{
                    a = '1' + a;
                }
            }
            
        }
    }
    
    return a;
}

//减法要考虑多种情况  0 － ＋
string sub(string s1,string s2)
{
    //00000
    if (s2 == "0") {
        return s1;
    }
    if (s1 == "0") {
        if (s2[0] == '-') {
            return s2.erase(0,1);
        }
        return "-" + s2;
    }
    //-------
    if (s1[0] == '-') {
        if (s2[0] == '-') {
            return sub(s2.erase(0,1), s1.erase(0,1));
        }
        return "-" + add(s1.erase(0,1), s2);
    }
    // "-" - "+"
    if (s2[0] == '-') {
        return add(s1, s2.erase(0,1));
    }
    string::size_type i,size1,size2;
    size1 = s1.size();
    size2 = s2.size();
    if (size1 < size2) {
        for (int i = 0; i < (size2 - size1); i++) {
            s1 = "0" + s1;
        }
    }else{
        for(i = 0; i < (size1 - size2);i++)
            s2 = "0" + s2;
    }
    
    int t = s1.compare(s2); //t > 0说明s1的值比s2大，减出来是整数
    if(t < 0)
    {
        return "-" + sub(s2, s1);
    }
    if (t == 0) {
        return 0;
    }
    //s1 > s2时
    string result;
    string::size_type j;
    for( i= s1.size() - 1 ; i != 0 ; i--)
    {
        if (s1[i] < s2[i]) {
            j = 1;
            while (s1[i - j] == '0') {
                s1[i - j] = '9';
                j++;
            }
            s1[i - j] -= 1;
            result = char(s1[i] + 58 - s2[i]) + result;
        }else
        {
            result = char(s1[i] + '0' - s2[i]) + result;
        }
    }
    result = char(s1[0] + '0' - s2[0]) + result;
    result.erase(0,result.find_first_not_of('0'));
    return result;
    
}
//在字符串的右边加0
string add_zero(string& a, int len)
{
    for(int i = 0; i < len; i++)
        a = a + '0';
    
    return a;
}

/*递归计算大整数乘积
 a = a1* 10^a0.length()+a0
 b = b1* 10^b0.length()+b0
 a*b = a1*b1*10^(a0.length()+b0.length())
 +a1*b0*10^a0.length()+a0*b1*10^b0.length()+a0*b0
 */
string bigInt_mutiply(string& a, string& b)
{
    if (a == "0" || b == "0") {
        return "0";
    }
    int sign = 1;
    if (a[0] == '-') {
        sign *= -1;
        a.erase(0,1);
    }
    if (b[0] == '-') {
        sign *= -1;
        b.erase(0,1);
    }
    if(a.length() ==1 || b.length() == 1)
        return mutiply(a, b);
    
    else{
        string a1 = a.substr(0, a.length()/2);
        string a0 = a.substr(a1.length()); //复制从a1之后的位数
        string b1 = b.substr(0, b.length()/2);
        string b0 = b.substr(b1.length());
        
        string c0 = bigInt_mutiply(a0, b0);
        string c1 = bigInt_mutiply(a1, b0);
        string c2 = bigInt_mutiply(a0, b1);
        string c3 = bigInt_mutiply(a1, b1);
        
        c3 = add_zero(c3, a0.length()+b0.length());
        c2 = add_zero(c2, b0.length());
        c1 = add_zero(c1, a0.length());
        
        add(c3, c2);
        add(c3, c1);
        add(c3, c0);
        
        if (sign == -1) {
            return "-" + c3;
        }
        return c3;
    }
}

int main()
{
    string a, b;
    int op;
    while(cin>>a>>b>>op){
        //cout<<bigInt_mutiply(a, b)<<endl;
        switch (op) {
            case 1:
                cout<<add(a, b)<<endl;
                break;
            case 2:
                cout<<sub(a, b)<<endl;
                break;
            case 3:
                cout<<mutiply(a, b)<<endl;
                break;
            default:
                cout<<"The Operator input error!"<<endl;
                break;
        }
    }
    //system("PAUSE");
    return 0;
}