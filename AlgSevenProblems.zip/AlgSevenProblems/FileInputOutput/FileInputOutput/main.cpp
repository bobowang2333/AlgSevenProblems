//
//  main.cpp
//  FileInputOutput
//
//  Created by bobobo on 11/8/15.
//  Copyright © 2015 bobobo. All rights reserved.
//
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <vector>
#include <iostream>
#include <fstream>
#include <cstdlib>
//#include "stdafx.h"
int n ;  //n组测试数据
const int MaxSize = 100000 + 10; //最大点数
const double infinity = 1e20;       //无穷大距离
struct Point
{
    int x, y;
    Point(int  a = 0, int b = 0) : x(a), y(b) {}
} v[MaxSize], tem[MaxSize];     //点集, 中间点集
struct PointPair
{
    int x1;
    int y1;
    int x2;
    int y2;
}vP[MaxSize];
using namespace std;

bool CompareX (const Point &p1, const Point &p2) { return p1.x < p2.x; }
bool CompareY (const Point &p1, const Point &p2) { return p1.y < p2.y; }

//计算欧几里得距离
inline double calDis(const Point &p1, const Point &p2)
{
    return sqrt((p1.x-p2.x)*(p1.x-p2.x) + (p1.y-p2.y)*(p1.y-p2.y));
}

int findVertex(Point arr[],int n, int x,int y)
{
    int i = 0;
    int index = -1;
    for (i = 0; i < n; i++) {
        if((x == arr[i].x)&&(y == arr[i].y))
        {
            index = i;
            break;
        }
    }
    return index;
}
//寻找下标在[st, ed]之间的最近点对
double closestPair(int st, int ed, int &p1, int &p2)
{
    double dis = infinity, temdis;
    //int lenArray[MaxSize];
    if (st >= ed) return dis;
    //int m = ed - st;
    int mid = st + ((ed - st) >> 1);
    int t1 ,t2;
    if ((temdis = closestPair(st, mid, t1, t2)) < dis)  //左边
        dis = temdis, p1 = t1, p2 = t2;
    if ((temdis = closestPair(mid+1, ed, t1, t2)) < dis)//右边
        dis = temdis, p1 = t1, p2 = t2;
    
    //寻找距离中间x坐标小于dis的点，并按Y坐标排序
    int len = 0;
    for (int i = st; i <= ed; i++)
        if (fabs(v[i].x - v[mid].x) < dis)
        {
            tem[len++] = v[i];
            //lenArray[len++] = i;
        }
    sort(tem, tem + len, CompareY);
    
    //考虑每个点附近至多8个点，由距离控制
    for (int i = 0; i < len; i++)
        for (int j = i + 1; ((j < len )&& ((tem[j].y - tem[i].y) <= dis)); j++)
            if ((temdis = calDis(tem[i], tem[j])) < dis)
            {
                dis = temdis;
                p1 = findVertex(v, n, tem[i].x, tem[i].y);
                p2 = findVertex(v, n, tem[j].x, tem[j].y);
            }
    return dis;
}


int main()
{
    ifstream fin("/users/bobobo/Documents/AlgSevenProblems/FileInputOutput/in.dat",ios::in|ios::binary);
    if(!fin)
    {
        cerr<<"open error!"<<endl;
        abort( );
    }
    fin.read((char *)&n, sizeof(n));
    ofstream fout("out.dat",ios::binary);
    if(!fout)
    {
        cerr<<"open error!"<<endl;
        abort( );//退出程序
    }
    int j;
    for(int i = 0 ; i < n ; i++)
    {
        fin.read((char *)&j, sizeof(j));//std::getline(fin,lineStr);
        //int j = std::stoi(lineStr);    //j=>这一组的测试数据的个数
        for (int k = 0; k < j; k++) {
            fin.read((char *)&v[k], sizeof(v[k]));
        }
        sort(v, v + j, CompareX);
        int k1, k2;
        double dis = closestPair(0, j - 1, k1, k2);
        vP[i].x1 = v[k1].x;
        vP[i].y1 = v[k1].y;
        vP[i].x2 = v[k2].x;
        vP[i].y2 = v[k2].y;
        fout.write((char *)&vP[i], sizeof(vP[i]));  //写进n组数据作为最小值
    }
    
}
        
