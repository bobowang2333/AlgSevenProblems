//
//  main.cpp
//  FlyodAlgorithm
//
//  Created by bobobo on 11/13/15.
//  Copyright © 2015 bobobo. All rights reserved.
//

#include <iostream>
#include <fstream>
using namespace std;

#define MaxVertice 100
#define MaxEdge 50
#define oo 65535   //表示两点间距离为无穷大

typedef int PointPath [MaxVertice][MaxVertice];
typedef int ShortPathTable [MaxVertice][MaxVertice];

typedef struct
{
    int vertice[MaxVertice];
    int IngTable[MaxVertice][MaxVertice];
    int numVertice,numEdge;
} MatrixGraph;

void createMatrixMap(MatrixGraph *m)
{
    int i ,j,n;
    cout<<"Please input the Vertice Number"<<endl;
    scanf("%d",&n);
    m->numVertice = n;
    for ( i = 0; i < n; i++) {
        m->vertice[i] = i;
    }
    //初始化
    for (i = 0; i < n; i++)
        for (j = 0;  j < n; j++) {
            if (i == j) {
                m->IngTable[i][j] = 0;
            }else
            {
                m->IngTable[i][j] = oo;
            }
        }
    //输入数据
    for (int i = 0;  i < n; i++)
        for (int j = 0; j < n; j++) {
            if (i == j) {
                m->IngTable[i][j] = 0;
            }else
            {
                cout<<"input the length of distance of("<<i<<","<<j<<")"<<endl;
                cin>>m->IngTable[i][j];
            }
        }
    
}

void Flyod(MatrixGraph m1,PointPath d, ShortPathTable p)
{
    for (int i = 0; i < m1.numVertice; i++)
        for (int j = 0; j < m1.numVertice; j++) {
            d[i][j] = m1.IngTable[i][j];
            p[i][j] = j;
        }
    for (int k = 0; k < m1.numVertice; k++)
        for (int i = 0; i < m1.numVertice; i++)
            for(int j = 0;j < m1.numVertice;j++)
            {
                if (d[i][j] > (d[i][k] + d[k][j])) {
                    d[i][j] = d[i][k] + d[k][j];
                    p[i][j] = p[i][k];  //路径设置经过下标为k的端点
                }
            }
            
}
int main(int argc, const char * argv[]) {
    // insert code here...
    ifstream fin("/users/bobobo/Documents/OcTrial/FlyodAlgorithm/FlyodAlgorithm/in.dat",ios::binary|ios::in);
    if(!fin)
    {
        cerr<<"open error!"<<endl;
        abort();
    }
    int n ;
    fin.read((char *)&n, sizeof(n));
    MatrixGraph m[n];
    PointPath d[n];
    ShortPathTable p[n];
    //有n组测试项
    //fin.read((char *)&n, sizeof(n));
    ofstream fout("out.dat",ios::binary|ios::out);
    
    fout.write((char *)&n, sizeof(n));
    for (int i = 0; i < n; i++) {
        int j;
        fin.read((char *)&j, sizeof(j));
        //本组的测试点数
        fout.write((char *)&j,sizeof(j));
        m[i].numVertice = j;
        for (int a = 0; a < j; a++) {
                fin.read((char *)&(m[i].IngTable[a]), sizeof(m[i].IngTable[a]));
            }
        for (int b = 0 ;b < j; b++) {
            m[i].IngTable[b][b] = 0;
        }
            Flyod(m[i], d[i], p[i]);
            //n 行数据 每行也有n个数据 代表最短距离 n  * n矩阵 每个节点值代表图中的两点间最短距离
            for (int e = 0;  e < j; e++) {
                fout.write((char *)&(d[i][e]), sizeof(d[i][e])); //写入一行数据
            }
        for (int x = 0; x < j; x++) {
            fout.write((char *)&(p[i][x]), sizeof(p[i][x]));//写入一行数据
        }
            // 前驱矩阵代表其中的点
            /*
            int vertice[j*j][j];
            int k,num1;
            for (int x = 0; x < j; x++) {
                for (int y = 0; y < j; y++) {
                    //此时 位于矩阵中的点为[x][y] 是第i组测试数据
                     k = p[i][x][y];
                     num1 = 0;
                    
                    while (k != y) {
                        vertice[x*j+y][num1] = k;
                        num1++;
                        k = p[i][k][y];
                    }
                    vertice[x*j+y][num1] = y;
                    //图中代表 (n*n)*n矩阵  代表n*n对节点 的前驱节点
                    fout.write((char *)&(vertice[x*j+y]), sizeof(vertice[x*j+y]));
                }
            }*/
            
        }
    fin.close();
    fout.close();
    return 0;
}
    /*
    int k;
    MatrixGraph mGraph;
    PointPath d;
    ShortPathTable p;
    createMatrixMap(&mGraph);
    Flyod(mGraph, d, p);
    cout << "the shortest path is:"<<endl;
    for (int i = 0; i < mGraph.numVertice; i++) {
        for (int j = 0; j < mGraph.numVertice; j++) {
            cout<<"the vertice:"<<i<<"-"<<j<<"-distance:"<<d[i][j]<<endl;
            int k = p[i][j];
            cout<<"the path is :"<<i<<endl;
            while (k != j) {
                cout << "->" <<k<<" ";
                k= p[k][j];
            }
            cout <<"->"<<j<<endl;
        }
        cout << endl;
    }*/

