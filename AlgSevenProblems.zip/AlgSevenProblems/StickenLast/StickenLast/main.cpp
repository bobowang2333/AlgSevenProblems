//
//  main.cpp
//  StickenLast
//
//  Created by bobobo on 11/14/15.
//  Copyright © 2015 bobobo. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <memory.h>
#include <algorithm>
using namespace std;

#define MAXN 10050

struct Node{
    int x,y;
}node[MAXN];


bool cmp(const Node& a,const Node& b)
{
    if(a.y == b.y)
        return a.x<b.x;
    return a.y<b.y;
}

int bsearch1(int c[],int n,Node a)
{
    int l = 1,r = n;
    while (l <= r) {
        int mid = (l+r)/2;
        if((c[mid] > a.x)&&(c[mid + 1] <= a.x))
            return mid+1;
        else if (c[mid] < a.x)
            r = mid - 1;
        else
            l = mid + 1;
    }
    return -1;
}
int LDS(Node a[],int n)
{
    int i,j,size = 1;
    int *c = new int[n+1];
    int *dp = new int [n+1];
    c[1] = a[0].x;
    dp[1] = 1;
    for (i = 1; i < n; i++) {
        if (a[i].x >= c[1])
            j = 1;
        else if(a[i].x < c[size])
            j = ++size;
        else
            j = bsearch1(c,size,*a);
        c[j] = a[i].x;
        dp[i] = j;
    }
    return size;
}

int main()
{
    int Num;
    scanf("%d",&Num);
    int n;
    while (Num--) {
        scanf("%d",&n);
        for (int i = 0; i < n; i++) {
            scanf("%d %d",&node[i].x,&node[i].y);
        }
        sort(node,node+n,cmp);
        int res = LDS(node, n);
        cout<<res;
    }
}
